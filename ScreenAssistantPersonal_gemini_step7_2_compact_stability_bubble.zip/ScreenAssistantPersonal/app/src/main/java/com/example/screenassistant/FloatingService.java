package com.example.screenassistant;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Button;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.ByteBuffer;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class FloatingService extends Service {
    private static final String CHANNEL_ID = "screen_assistant_capture";

    private WindowManager windowManager;
    private TextView bubble;
    private LinearLayout answerPanel;
    private ScrollView answerScroll;
    private TextView answerText;
    private TextView headerTitle;
    private WindowManager.LayoutParams answerParams;

    private MediaProjection mediaProjection;
    private VirtualDisplay virtualDisplay;
    private ImageReader imageReader;
    private final Handler handler = new Handler(Looper.getMainLooper());

    private int screenWidth;
    private int screenHeight;
    private int screenDensity;

    private int initialX, initialY;
    private float initialTouchX, initialTouchY;
    private long downTime;
    private boolean busy = false;
    private boolean panelMinimized = false;
    private int requestCounter = 0;
    private int activeRequest = 0;

    @Override
    public void onCreate() {
        super.onCreate();
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        createNotificationChannel();
        startForeground(1, buildNotification("Z.D.SURV is ready"));

        if (intent != null && "ACTION_STOP_FLOATING".equals(intent.getAction())) {
            stopSelf();
            return START_NOT_STICKY;
        }

        if (bubble != null && mediaProjection != null) {
            return START_STICKY;
        }

        if (intent == null || !intent.hasExtra("resultCode") || !intent.hasExtra("data")) {
            Toast.makeText(this, "Missing screen capture permission. Open the app and press Start again.", Toast.LENGTH_LONG).show();
            stopSelf();
            return START_NOT_STICKY;
        }

        int resultCode = intent.getIntExtra("resultCode", 0);
        Intent data = intent.getParcelableExtra("data");
        MediaProjectionManager projectionManager = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        mediaProjection = projectionManager.getMediaProjection(resultCode, data);
        if (Build.VERSION.SDK_INT >= 21) {
            mediaProjection.registerCallback(new MediaProjection.Callback() {
                @Override
                public void onStop() {
                    cleanupProjection();
                }
            }, handler);
        }

        screenWidth = getResources().getDisplayMetrics().widthPixels;
        screenHeight = getResources().getDisplayMetrics().heightPixels;
        screenDensity = getResources().getDisplayMetrics().densityDpi;

        setupImageReader();
        showBubble();
        return START_STICKY;
    }

    private void setupImageReader() {
        cleanupProjectionDisplayOnly();
        imageReader = ImageReader.newInstance(screenWidth, screenHeight, PixelFormat.RGBA_8888, 2);
        virtualDisplay = mediaProjection.createVirtualDisplay(
                "ScreenAssistantCapture",
                screenWidth,
                screenHeight,
                screenDensity,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                imageReader.getSurface(),
                null,
                handler
        );
    }

    private void showBubble() {
        if (bubble != null) return;

        bubble = new TextView(this);
        bubble.setText("Z");
        bubble.setTextSize(22f);
        bubble.setTypeface(Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD));
        bubble.setTextColor(Color.WHITE);
        bubble.setGravity(Gravity.CENTER);
        bubble.setAlpha(0.86f);
        bubble.setBackground(makeRoundDrawable(Color.argb(220, 137, 104, 198), Color.argb(170, 245, 241, 255), dp(999)));
        bubble.setPadding(dp(14), dp(10), dp(14), dp(10));

        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                dp(56),
                dp(56),
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT
        );
        params.gravity = Gravity.BOTTOM | Gravity.END;
        params.x = dp(18);
        params.y = dp(92);

        bubble.setOnTouchListener((view, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    downTime = System.currentTimeMillis();
                    initialX = params.x;
                    initialY = params.y;
                    initialTouchX = event.getRawX();
                    initialTouchY = event.getRawY();
                    return true;
                case MotionEvent.ACTION_MOVE:
                    params.x = initialX + (int) (event.getRawX() - initialTouchX);
                    params.y = initialY - (int) (event.getRawY() - initialTouchY);
                    windowManager.updateViewLayout(bubble, params);
                    return true;
                case MotionEvent.ACTION_UP:
                    float moved = Math.abs(event.getRawX() - initialTouchX) + Math.abs(event.getRawY() - initialTouchY);
                    long duration = System.currentTimeMillis() - downTime;
                    if (moved < 20) {
                        if (duration > 800) {
                            Toast.makeText(this, "Closing floating button", Toast.LENGTH_SHORT).show();
                            stopSelf();
                        } else {
                            captureNow();
                        }
                    }
                    return true;
            }
            return false;
        });

        windowManager.addView(bubble, params);
    }

    private void captureNow() {
        if (busy) {
            showAnswer("ما زال التحليل جارياً... انتظر قليلاً.", true);
            return;
        }
        busy = true;
        if (bubble != null) {
            bubble.setText("...");
            bubble.setVisibility(View.INVISIBLE);
        }
        if (answerPanel != null) answerPanel.setVisibility(View.INVISIBLE);

        // نخفي النوافذ العائمة لحظة الالتقاط حتى يرى Gemini الصفحة الأصلية وليس نافذتنا.
        handler.postDelayed(() -> {
            Image image = null;
            Bitmap cropped = null;
            try {
                image = imageReader.acquireLatestImage();
                if (bubble != null) bubble.setVisibility(View.VISIBLE);
                if (answerPanel != null) answerPanel.setVisibility(View.VISIBLE);

                if (image == null) {
                    showAnswer("ما قدرت ألتقط الصورة. جرّب اضغط AI مرة ثانية.", false);
                    finishBusy();
                    return;
                }

                Image.Plane[] planes = image.getPlanes();
                ByteBuffer buffer = planes[0].getBuffer();
                int pixelStride = planes[0].getPixelStride();
                int rowStride = planes[0].getRowStride();
                int rowPadding = rowStride - pixelStride * screenWidth;

                Bitmap bitmap = Bitmap.createBitmap(
                        screenWidth + rowPadding / pixelStride,
                        screenHeight,
                        Bitmap.Config.ARGB_8888
                );
                bitmap.copyPixelsFromBuffer(buffer);
                cropped = Bitmap.createBitmap(bitmap, 0, 0, screenWidth, screenHeight);
                bitmap.recycle();

                saveBitmap(cropped);
                int requestId = ++requestCounter;
                activeRequest = requestId;
                showAnswer("⏳ جارٍ تحليل الصفحة...\nيتم ضغط الصورة وإرسالها إلى Gemini. إذا كان النت ضعيفاً سيظهر خطأ واضح خلال 30 ثانية.", true);

                handler.postDelayed(() -> {
                    if (busy && activeRequest == requestId) {
                        activeRequest = -1;
                        showAnswer("⚠️ الاتصال بطيء أو Gemini تأخر بالرد.\nاضغط ↻ لإعادة التحليل، أو جرّب Wi‑Fi/نت أقوى.", false);
                        finishBusy();
                    }
                }, 30000);

                Bitmap finalBitmap = cropped;
                new Thread(() -> {
                    try {
                        String answer = askGemini(finalBitmap);
                        handler.post(() -> {
                            if (activeRequest == requestId) showAnswer(answer, false);
                        });
                    } catch (Exception e) {
                        handler.post(() -> {
                            if (activeRequest == requestId) showAnswer("خطأ Gemini/Network: " + e.getMessage() + "\nاضغط ↻ للمحاولة مرة ثانية.", false);
                        });
                    } finally {
                        finalBitmap.recycle();
                        handler.post(() -> {
                            if (activeRequest == requestId) finishBusy();
                        });
                    }
                }).start();

            } catch (Exception e) {
                if (bubble != null) bubble.setVisibility(View.VISIBLE);
                if (answerPanel != null) answerPanel.setVisibility(View.VISIBLE);
                if (cropped != null) cropped.recycle();
                showAnswer("خطأ أثناء الالتقاط: " + e.getMessage(), false);
                finishBusy();
            } finally {
                if (image != null) image.close();
            }
        }, 450);
    }

    private String askGemini(Bitmap screenshot) throws Exception {
        SharedPreferences prefs = getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE);
        String apiKey = prefs.getString(MainActivity.KEY_GEMINI_API_KEY, "");
        String model = prefs.getString(MainActivity.KEY_GEMINI_MODEL, MainActivity.DEFAULT_MODEL);
        String customInstructions = prefs.getString(MainActivity.KEY_CUSTOM_INSTRUCTIONS, MainActivity.DEFAULT_CUSTOM_INSTRUCTIONS);
        if (apiKey == null || apiKey.trim().isEmpty()) {
            return "Gemini API Key غير موجود. افتح التطبيق وضع المفتاح واضغط Save.";
        }
        if (model == null || model.trim().isEmpty()) model = MainActivity.DEFAULT_MODEL;

        String base64 = bitmapToBase64Jpeg(screenshot);
        String endpoint = "https://generativelanguage.googleapis.com/v1beta/models/" + model.trim() + ":generateContent";

        JSONObject inlineData = new JSONObject();
        inlineData.put("mime_type", "image/jpeg");
        inlineData.put("data", base64);

        JSONObject imagePart = new JSONObject();
        imagePart.put("inline_data", inlineData);

        JSONObject textPart = new JSONObject();
        String prompt = "تعليمات المستخدم الخاصة:\n" + (customInstructions == null ? "" : customInstructions.trim()) +
                "\n\nالمهمة الآن:\n" +
                "حلل كامل الشاشة الظاهرة كصفحة واحدة، ولا تركز على جزء صغير فقط. " +
                "أخرج النتيجة بهذا الشكل:\n" +
                "✅ الجواب المقترح: اكتب الجواب النهائي أولاً وباختصار.\n" +
                "🔎 السؤال/المهمة: استخرج السؤال أو المطلوب من الصفحة.\n" +
                "📌 الخيارات الظاهرة: اذكر الخيارات إن وجدت.\n" +
                "💡 السبب: سبب قصير جداً.\n" +
                "🎯 الثقة: عالية/متوسطة/منخفضة.\n" +
                "إذا كانت الصفحة ليست سؤالاً، اشرح ما يظهر وما الخطوة العملية التالية. اكتب بالعربية الواضحة والمختصرة.";
        textPart.put("text", prompt);

        JSONArray parts = new JSONArray();
        parts.put(textPart);
        parts.put(imagePart);

        JSONObject content = new JSONObject();
        content.put("parts", parts);

        JSONArray contents = new JSONArray();
        contents.put(content);

        JSONObject generationConfig = new JSONObject();
        generationConfig.put("temperature", 0.2);
        generationConfig.put("maxOutputTokens", 1000);

        JSONObject body = new JSONObject();
        body.put("contents", contents);
        body.put("generationConfig", generationConfig);

        HttpURLConnection conn = (HttpURLConnection) new URL(endpoint).openConnection();
        conn.setRequestMethod("POST");
        conn.setConnectTimeout(30000);
        conn.setReadTimeout(30000);
        conn.setDoOutput(true);
        conn.setRequestProperty("Content-Type", "application/json");
        conn.setRequestProperty("x-goog-api-key", apiKey.trim());

        OutputStream os = conn.getOutputStream();
        os.write(body.toString().getBytes("UTF-8"));
        os.close();

        int code = conn.getResponseCode();
        InputStream input = code >= 200 && code < 300 ? conn.getInputStream() : conn.getErrorStream();
        String response = readAll(input);
        conn.disconnect();

        if (code < 200 || code >= 300) {
            return "Gemini رجّع خطأ HTTP " + code + ":\n" + response;
        }
        return extractGeminiText(response);
    }

    private String extractGeminiText(String json) {
        try {
            JSONObject root = new JSONObject(json);
            JSONArray candidates = root.optJSONArray("candidates");
            if (candidates == null || candidates.length() == 0) return "Gemini لم يرجع جواباً واضحاً.";
            JSONObject content = candidates.getJSONObject(0).optJSONObject("content");
            if (content == null) return "Gemini لم يرجع محتوى واضحاً.";
            JSONArray parts = content.optJSONArray("parts");
            if (parts == null || parts.length() == 0) return "Gemini لم يرجع نصاً.";

            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < parts.length(); i++) {
                String text = parts.getJSONObject(i).optString("text", "");
                if (!text.isEmpty()) sb.append(text).append("\n");
            }
            String result = sb.toString().trim();
            return result.isEmpty() ? "Gemini لم يرجع نصاً." : result;
        } catch (Exception e) {
            return "وصل رد من Gemini لكن لم أستطع قراءته:\n" + json;
        }
    }

    private String bitmapToBase64Jpeg(Bitmap bitmap) throws Exception {
        int maxWidth = 900;
        Bitmap scaled = bitmap;
        if (bitmap.getWidth() > maxWidth) {
            int newHeight = (int) (((float) bitmap.getHeight() / bitmap.getWidth()) * maxWidth);
            scaled = Bitmap.createScaledBitmap(bitmap, maxWidth, newHeight, true);
        }
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        scaled.compress(Bitmap.CompressFormat.JPEG, 72, baos);
        if (scaled != bitmap) scaled.recycle();
        return Base64.encodeToString(baos.toByteArray(), Base64.NO_WRAP);
    }

    private String readAll(InputStream input) throws Exception {
        if (input == null) return "";
        BufferedReader br = new BufferedReader(new InputStreamReader(input, "UTF-8"));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = br.readLine()) != null) sb.append(line).append('\n');
        br.close();
        return sb.toString().trim();
    }

    private Uri saveBitmap(Bitmap bitmap) {
        try {
            String time = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
            String fileName = "screen_assistant_" + time + ".jpg";

            ContentResolver resolver = getContentResolver();
            ContentValues values = new ContentValues();
            values.put(MediaStore.Images.Media.DISPLAY_NAME, fileName);
            values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
            if (Build.VERSION.SDK_INT >= 29) {
                values.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/ScreenAssistant");
                values.put(MediaStore.Images.Media.IS_PENDING, 1);
            }

            Uri uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
            if (uri == null) return null;

            OutputStream out = resolver.openOutputStream(uri);
            bitmap.compress(Bitmap.CompressFormat.JPEG, 90, out);
            if (out != null) out.close();

            if (Build.VERSION.SDK_INT >= 29) {
                values.clear();
                values.put(MediaStore.Images.Media.IS_PENDING, 0);
                resolver.update(uri, values, null, null);
            }
            return uri;
        } catch (Exception e) {
            return null;
        }
    }

    private void ensureAnswerPanel(boolean loading) {
        if (answerPanel != null) return;

        answerPanel = new LinearLayout(this);
        answerPanel.setOrientation(LinearLayout.VERTICAL);
        answerPanel.setBackground(makeRoundDrawable(Color.argb(248, 249, 247, 253), Color.rgb(203, 187, 234), dp(30)));
        answerPanel.setPadding(dp(14), dp(11), dp(14), dp(12));

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);

        headerTitle = new TextView(this);
        headerTitle.setTextColor(Color.rgb(58, 48, 78));
        headerTitle.setTypeface(Typeface.DEFAULT_BOLD);
        headerTitle.setTextSize(18f);
        headerTitle.setText(loading ? "Z.D.SURV • analyzing" : "Z.D.SURV • answer");

        LinearLayout.LayoutParams titleLp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        header.addView(headerTitle, titleLp);

        TextView again = makeHeaderButton("↻");
        again.setOnClickListener(v -> captureNow());
        header.addView(again);

        TextView copy = makeHeaderButton("Copy");
        copy.setTextSize(14f);
        copy.setOnClickListener(v -> copyAnswer());
        header.addView(copy);

        TextView minimize = makeHeaderButton(panelMinimized ? "□" : "—");
        minimize.setOnClickListener(v -> togglePanelMinimize());
        header.addView(minimize);

        TextView close = makeHeaderButton("✕");
        close.setOnClickListener(v -> removeAnswerPanel());
        header.addView(close);

        header.setOnTouchListener(new DragTouchListener());
        answerPanel.addView(header, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        answerScroll = new ScrollView(this);
        answerText = new TextView(this);
        answerText.setTextColor(Color.rgb(52, 45, 67));
        answerText.setTextSize(15.2f);
        answerText.setLineSpacing(dp(2), 1.16f);
        answerText.setPadding(dp(2), dp(10), dp(2), dp(8));
        answerScroll.addView(answerText);
        answerPanel.addView(answerScroll, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(310)));

        TextView footer = new TextView(this);
        footer.setTextColor(Color.rgb(126, 108, 158));
        footer.setTextSize(12f);
        footer.setText("X إغلاق • Copy نسخ • ↻ تحليل جديد • اسحب العنوان لتحريك النافذة");
        answerPanel.addView(footer, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        answerParams = new WindowManager.LayoutParams(
                screenWidth - dp(32),
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT
        );
        answerParams.gravity = Gravity.TOP | Gravity.START;
        answerParams.x = dp(16);
        answerParams.y = dp(78);

        windowManager.addView(answerPanel, answerParams);
    }

    private TextView makeHeaderButton(String label) {
        TextView tv = new TextView(this);
        tv.setText(label);
        tv.setTextColor(Color.rgb(58, 48, 78));
        tv.setTextSize(16f);
        tv.setTypeface(Typeface.DEFAULT_BOLD);
        tv.setGravity(Gravity.CENTER);
        tv.setPadding(dp(9), dp(6), dp(9), dp(6));
        tv.setBackground(makeRoundDrawable(Color.rgb(239, 234, 248), Color.rgb(203, 187, 234), dp(14)));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.setMargins(dp(4), 0, 0, 0);
        tv.setLayoutParams(lp);
        return tv;
    }

    private class DragTouchListener implements View.OnTouchListener {
        private int startX, startY;
        private float touchX, touchY;

        @Override
        public boolean onTouch(View v, MotionEvent event) {
            if (answerParams == null) return false;
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    startX = answerParams.x;
                    startY = answerParams.y;
                    touchX = event.getRawX();
                    touchY = event.getRawY();
                    return true;
                case MotionEvent.ACTION_MOVE:
                    answerParams.x = startX + (int) (event.getRawX() - touchX);
                    answerParams.y = startY + (int) (event.getRawY() - touchY);
                    if (answerPanel != null) windowManager.updateViewLayout(answerPanel, answerParams);
                    return true;
            }
            return false;
        }
    }

    private void togglePanelMinimize() {
        if (answerPanel == null || answerScroll == null || answerParams == null) return;
        panelMinimized = !panelMinimized;
        answerScroll.setVisibility(panelMinimized ? View.GONE : View.VISIBLE);
        int footerIndex = 2;
        if (answerPanel.getChildCount() > footerIndex) {
            View footer = answerPanel.getChildAt(footerIndex);
            footer.setVisibility(panelMinimized ? View.GONE : View.VISIBLE);
        }
        answerParams.height = WindowManager.LayoutParams.WRAP_CONTENT;
        windowManager.updateViewLayout(answerPanel, answerParams);
    }

    private void removeAnswerPanel() {
        try {
            if (answerPanel != null) {
                windowManager.removeView(answerPanel);
            }
        } catch (Exception ignored) {
        }
        answerPanel = null;
        answerScroll = null;
        answerText = null;
        headerTitle = null;
        answerParams = null;
        panelMinimized = false;
    }

    private void showAnswer(String text, boolean loading) {
        ensureAnswerPanel(loading);
        if (headerTitle != null) headerTitle.setText(loading ? "Z.D.SURV • analyzing" : "Z.D.SURV • answer");
        if (answerText != null) answerText.setText(text);
        if (answerScroll != null) answerScroll.scrollTo(0, 0);
        if (answerPanel != null && panelMinimized) {
            togglePanelMinimize();
        }
    }

    private void copyAnswer() {
        try {
            if (answerText == null) return;
            ClipboardManager clipboard = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
            clipboard.setPrimaryClip(ClipData.newPlainText("Gemini answer", answerText.getText().toString()));
            Toast.makeText(this, "Copied", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Copy failed", Toast.LENGTH_SHORT).show();
        }
    }

    private void finishBusy() {
        busy = false;
        if (bubble != null) bubble.setText("Z");
    }

    private Notification buildNotification(String text) {
        Intent openIntent = new Intent(this, MainActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(
                this,
                0,
                openIntent,
                Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0
        );

        Notification.Builder builder = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL_ID)
                : new Notification.Builder(this);

        return builder
                .setContentTitle("Z.D.SURV")
                .setContentText(text)
                .setSmallIcon(android.R.drawable.ic_menu_camera)
                .setContentIntent(pendingIntent)
                .setOngoing(true)
                .build();
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    "Screen Assistant Capture",
                    NotificationManager.IMPORTANCE_LOW
            );
            NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            manager.createNotificationChannel(channel);
        }
    }

    private void cleanupProjectionDisplayOnly() {
        if (virtualDisplay != null) {
            virtualDisplay.release();
            virtualDisplay = null;
        }
        if (imageReader != null) {
            imageReader.close();
            imageReader = null;
        }
    }

    private void cleanupProjection() {
        cleanupProjectionDisplayOnly();
        mediaProjection = null;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        try {
            if (bubble != null) windowManager.removeView(bubble);
        } catch (Exception ignored) {
        }
        removeAnswerPanel();
        cleanupProjectionDisplayOnly();
        if (mediaProjection != null) {
            mediaProjection.stop();
            mediaProjection = null;
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    private GradientDrawable makeRoundDrawable(int fill, int stroke, int radius) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setShape(GradientDrawable.RECTANGLE);
        drawable.setColor(fill);
        drawable.setCornerRadius(radius);
        drawable.setStroke(dp(1), stroke);
        return drawable;
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density);
    }
}
