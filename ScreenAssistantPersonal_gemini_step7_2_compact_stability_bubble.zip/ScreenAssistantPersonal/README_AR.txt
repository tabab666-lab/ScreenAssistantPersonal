Z.D.SURV - Step 7.2 Compact Panel + Stability

الجديد:
- زر عائم أنعم وشفاف قليلاً، دائري، ومكانه أسفل اليمين.
- نافذة جواب compact قريبة من نموذج ASK AI: عرض واضح، ارتفاع أقل، وScroll داخلي.
- ضغط الصورة قبل الإرسال لتقليل التعليق مع النت الضعيف.
- Timeout بعد 30 ثانية مع رسالة خطأ واضحة وزر إعادة التحليل ↻.
- تحسين Copy / Retry / Close / Minimize.
- نفس ميزات 6 Survey Profiles وتعليمات Gemini.

طريقة الاستخدام:
1. ضع Gemini API Key واحفظ.
2. اختَر Survey Profile إن أردت.
3. START FLOATING AI.
4. اضغط زر Z العائم ضغطة قصيرة لتحليل الشاشة.
