Z.D.SURV - Final Personal Build

النسخة النهائية تشمل:
- زر عائم Z شفاف وأنيق.
- تحليل Screenshot عبر Gemini API.
- Auto mode مع fallback بين Pro / Flash / Flash Lite عند حدود الاستخدام.
- زر Gemini الرسمي للاستفادة من اشتراك Gemini داخل التطبيق الرسمي عند الحاجة.
- 6 Survey Profiles بخانات منفصلة وذاكرة لكل بروفايل.
- German Learning mode.
- Settings: اللغة + Light/Dark mode.
- ألوان Z.D.SURV الفخمة.
- معالجة 429/Quota برسائل مفهومة.
- رفع maxOutputTokens ومنع قص الجواب.
- ضغط الصورة قبل الإرسال وتحسين الثبات.
- نافذة جواب قابلة للسحب، Copy، Retry، Close.
- جديد: يمكن الضغط المطول على نص التحليل لتحديد جزء منه ونسخه، بالإضافة إلى زر Copy لنسخ الجواب كامل.

طريقة البناء:
ارفع ZIP إلى GitHub بنفس workflow السابق، ثم Actions > Build APK > Download artifact.
