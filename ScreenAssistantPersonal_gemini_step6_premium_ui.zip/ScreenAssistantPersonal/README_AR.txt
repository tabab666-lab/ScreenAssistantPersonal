Screen Assistant + Gemini - Step 6 UI

ما الجديد:
1) شكل Premium داكن وألوان متناسقة.
2) زر AI دائري أنيق بدل الشكل المربع.
3) نافذة جواب بزوايا دائرية وأزرار Copy و X و ↻ بشكل أجمل.
4) جواب Gemini صار منظماً: الجواب المقترح، السؤال، الخيارات، السبب، مستوى الثقة.
5) نفس خانة Custom instructions موجودة، وكل تحليل يعتمد عليها.

طريقة الاستخدام:
- ضع Gemini API Key الحقيقي الذي يبدأ غالباً بـ AIza.
- اترك Gemini model مثل gemini-2.5-flash.
- اكتب تعليماتك في Custom instructions.
- اضغط SAVE SETTINGS.
- اضغط START FLOATING AI.
- اضغط AI فوق أي صفحة لتحليل كامل الشاشة.
