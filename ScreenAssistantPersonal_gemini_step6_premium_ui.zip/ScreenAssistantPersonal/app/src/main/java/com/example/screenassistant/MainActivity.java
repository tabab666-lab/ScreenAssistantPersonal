package com.example.screenassistant;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    public static final String PREFS = "screen_assistant_prefs";
    public static final String KEY_GEMINI_API_KEY = "gemini_api_key";
    public static final String KEY_GEMINI_MODEL = "gemini_model";
    public static final String KEY_CUSTOM_INSTRUCTIONS = "custom_instructions";
    public static final String DEFAULT_MODEL = "gemini-2.5-flash";
    public static final String DEFAULT_CUSTOM_INSTRUCTIONS = "حلل كامل الشاشة الظاهرة وليس جزءاً صغيراً فقط. إذا كانت الصفحة سؤال استبيان أو اختيار متعدد، استخرج السؤال والخيارات الظاهرة، ثم أعطني الإجابة/الخيارات المناسبة أولاً وبشكل واضح. بعدها أعطني سبباً قصيراً ومستوى ثقة. لا تطل الشرح. لا تختر شيئاً غير ظاهر إلا إذا كان منطقياً جداً بناءً على السياق.";

    private static final int REQ_OVERLAY = 100;
    private static final int REQ_SCREEN_CAPTURE = 200;
    private MediaProjectionManager projectionManager;
    private TextView statusText;
    private EditText apiKeyInput;
    private EditText modelInput;
    private EditText customInstructionsInput;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        projectionManager = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);

        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);

        ScrollView scroller = new ScrollView(this);
        scroller.setBackgroundColor(Color.rgb(11, 16, 32));
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        int pad = dp(18);
        root.setPadding(pad, pad, pad, pad);
        scroller.addView(root);

        TextView title = new TextView(this);
        title.setText("Ask AI Screen Assistant");
        title.setTextSize(26);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setTextColor(Color.WHITE);
        title.setGravity(Gravity.CENTER);

        TextView hint = new TextView(this);
        hint.setText("زر عائم أنيق + Gemini + تعليمات شخصية.\nاضغط AI فوق أي صفحة ليحلل الشاشة كاملة.");
        hint.setTextSize(14);
        hint.setTextColor(Color.rgb(203, 213, 225));
        hint.setGravity(Gravity.CENTER);
        hint.setPadding(0, dp(10), 0, dp(14));

        apiKeyInput = new EditText(this);
        apiKeyInput.setHint("Gemini API Key");
        apiKeyInput.setSingleLine(true);
        apiKeyInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        apiKeyInput.setText(prefs.getString(KEY_GEMINI_API_KEY, ""));
        styleInput(apiKeyInput);

        modelInput = new EditText(this);
        modelInput.setHint("Gemini model");
        modelInput.setSingleLine(true);
        modelInput.setText(prefs.getString(KEY_GEMINI_MODEL, DEFAULT_MODEL));
        styleInput(modelInput);

        customInstructionsInput = new EditText(this);
        customInstructionsInput.setHint("Custom instructions / معلوماتك وتعليماتك لجيميناي");
        customInstructionsInput.setMinLines(5);
        customInstructionsInput.setGravity(Gravity.TOP | Gravity.START);
        customInstructionsInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        customInstructionsInput.setText(prefs.getString(KEY_CUSTOM_INSTRUCTIONS, DEFAULT_CUSTOM_INSTRUCTIONS));
        styleInput(customInstructionsInput);

        Button saveButton = new Button(this);
        saveButton.setText("SAVE SETTINGS");
        styleButton(saveButton, Color.rgb(79, 70, 229));
        saveButton.setOnClickListener(v -> {
            String key = apiKeyInput.getText().toString().trim();
            String model = modelInput.getText().toString().trim();
            if (model.isEmpty()) model = DEFAULT_MODEL;
            prefs.edit()
                    .putString(KEY_GEMINI_API_KEY, key)
                    .putString(KEY_GEMINI_MODEL, model)
                    .putString(KEY_CUSTOM_INSTRUCTIONS, customInstructionsInput.getText().toString())
                    .apply();
            Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show();
            updateStatus();
        });

        statusText = new TextView(this);
        statusText.setTextSize(15);
        statusText.setTextColor(Color.rgb(226, 232, 240));
        statusText.setGravity(Gravity.CENTER);
        statusText.setPadding(dp(12), dp(14), dp(12), dp(14));
        statusText.setBackground(makeRoundDrawable(Color.rgb(15, 23, 42), Color.rgb(51, 65, 85), dp(18)));

        Button startButton = new Button(this);
        startButton.setText("START FLOATING AI");
        styleButton(startButton, Color.rgb(6, 182, 212));
        startButton.setOnClickListener(v -> startFlow());

        Button stopButton = new Button(this);
        stopButton.setText("STOP FLOATING BUTTON");
        styleButton(stopButton, Color.rgb(190, 18, 60));
        stopButton.setOnClickListener(v -> {
            stopService(new Intent(this, FloatingService.class));
            Toast.makeText(this, "Stopped", Toast.LENGTH_SHORT).show();
        });

        TextView help = new TextView(this);
        help.setText("نصائح:\n• اكتب بروفايلك أو طريقة الإجابة في Custom instructions.\n• الضغط القصير على AI يحلل الصفحة كاملة.\n• الضغط المطوّل على AI يغلق الزر العائم.\n• إذا علقت نافذة، زر STOP يغلق كل شيء.");
        help.setTextSize(13);
        help.setTextColor(Color.rgb(203, 213, 225));
        help.setPadding(dp(12), dp(16), dp(12), dp(0));

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, dp(6), 0, dp(10));
        root.addView(title, lp);
        root.addView(hint, lp);
        root.addView(apiKeyInput, lp);
        root.addView(modelInput, lp);
        root.addView(customInstructionsInput, lp);
        root.addView(saveButton, lp);
        root.addView(statusText, lp);
        root.addView(startButton, lp);
        root.addView(stopButton, lp);
        root.addView(help, lp);

        setContentView(scroller);

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 50);
        }

        updateStatus();
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateStatus();
    }

    private void startFlow() {
        String key = getSharedPreferences(PREFS, MODE_PRIVATE).getString(KEY_GEMINI_API_KEY, "");
        if (key == null || key.trim().isEmpty()) {
            Toast.makeText(this, "ضع Gemini API Key واضغط Save أولاً", Toast.LENGTH_LONG).show();
            return;
        }
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Enable Display over other apps", Toast.LENGTH_LONG).show();
            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
            startActivityForResult(intent, REQ_OVERLAY);
            return;
        }
        Intent captureIntent = projectionManager.createScreenCaptureIntent();
        startActivityForResult(captureIntent, REQ_SCREEN_CAPTURE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_SCREEN_CAPTURE) {
            if (resultCode == RESULT_OK && data != null) {
                Intent serviceIntent = new Intent(this, FloatingService.class);
                serviceIntent.putExtra("resultCode", resultCode);
                serviceIntent.putExtra("data", data);
                if (Build.VERSION.SDK_INT >= 26) {
                    startForegroundService(serviceIntent);
                } else {
                    startService(serviceIntent);
                }
                Toast.makeText(this, "Floating Gemini button started", Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(this, "Screen capture permission was not granted", Toast.LENGTH_LONG).show();
            }
        }
        updateStatus();
    }

    private void updateStatus() {
        boolean overlay = Settings.canDrawOverlays(this);
        String key = getSharedPreferences(PREFS, MODE_PRIVATE).getString(KEY_GEMINI_API_KEY, "");
        statusText.setText("Overlay permission: " + (overlay ? "Enabled" : "Disabled") +
                "\nGemini key: " + ((key != null && !key.trim().isEmpty()) ? "Saved" : "Missing") +
                "\nScreen capture: will ask when you press Start" +
                "\nضغط قصير على AI = تحليل الصفحة كاملة" +
                "\nضغط مطوّل على AI = إغلاق الزر العائم");
    }

    private void styleInput(EditText input) {
        input.setTextColor(Color.WHITE);
        input.setHintTextColor(Color.rgb(148, 163, 184));
        input.setTextSize(15);
        input.setPadding(dp(14), dp(10), dp(14), dp(10));
        input.setBackground(makeRoundDrawable(Color.rgb(15, 23, 42), Color.rgb(51, 65, 85), dp(16)));
    }

    private void styleButton(Button button, int color) {
        button.setTextColor(Color.WHITE);
        button.setTextSize(14);
        button.setTypeface(Typeface.DEFAULT_BOLD);
        button.setAllCaps(false);
        button.setPadding(dp(10), dp(12), dp(10), dp(12));
        button.setBackground(makeRoundDrawable(color, color, dp(18)));
    }

    private GradientDrawable makeRoundDrawable(int fill, int stroke, int radius) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setShape(GradientDrawable.RECTANGLE);
        drawable.setColor(fill);
        drawable.setCornerRadius(radius);
        drawable.setStroke(dp(1), stroke);
        return drawable;
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }
}
