package com.example.screenassistant;

import android.Manifest;
import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;

public class MainActivity extends Activity {
    public static final String PREFS = "screen_assistant_prefs";
    public static final String KEY_GEMINI_API_KEY = "gemini_api_key";
    public static final String KEY_GEMINI_MODEL = "gemini_model";
    public static final String KEY_CUSTOM_INSTRUCTIONS = "custom_instructions";
    public static final String KEY_ACTIVE_SURVEY_PROFILE = "active_survey_profile";
    public static final String KEY_SURVEY_PROFILE_PREFIX = "survey_profile_";
    public static final String KEY_LANGUAGE = "language";
    public static final String KEY_THEME = "theme";
    public static final String KEY_GERMAN_LEVEL = "german_level";
    public static final String KEY_GERMAN_GOAL = "german_goal";
    public static final String KEY_GERMAN_MODE = "german_mode";
    public static final String KEY_GERMAN_NOTES = "german_notes";
    public static final String DEFAULT_MODEL = "gemini-2.5-flash";
    public static final String DEFAULT_CUSTOM_INSTRUCTIONS = "حلل كامل الشاشة الظاهرة وليس جزءاً صغيراً فقط. إذا كانت الصفحة سؤال استبيان أو اختيار متعدد، استخرج السؤال والخيارات الظاهرة، ثم أعطني الإجابة/الخيارات المناسبة أولاً وبشكل واضح. بعدها أعطني سبباً قصيراً ومستوى ثقة. لا تطل الشرح. لا تختر شيئاً غير ظاهر إلا إذا كان منطقياً جداً بناءً على السياق.";

    private static final int REQ_OVERLAY = 100;
    private static final int REQ_SCREEN_CAPTURE = 200;
    private MediaProjectionManager projectionManager;
    private TextView statusText;
    private EditText apiKeyInput;
    private EditText modelInput;
    private EditText customInstructionsInput;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        projectionManager = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);

        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);

        ScrollView scroller = new ScrollView(this);
        scroller.setBackgroundColor(getScreenBgColor());
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        int pad = dp(18);
        root.setPadding(pad, pad, pad, pad);
        scroller.addView(root);

        TextView title = new TextView(this);
        title.setText("Z.D.SURV");
        title.setTextSize(26);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setTextColor(getPrimaryTextColor());
        title.setGravity(Gravity.CENTER);

        TextView hint = new TextView(this);
        hint.setText("Gemini screen assistant + personal survey profiles.\nاضغط AI فوق أي صفحة ليحلل الشاشة كاملة.");
        hint.setTextSize(14);
        hint.setTextColor(getSecondaryTextColor());
        hint.setGravity(Gravity.CENTER);
        hint.setPadding(0, dp(10), 0, dp(6));

        TextView developedBy = new TextView(this);
        developedBy.setText("Developed by Zain. D");
        developedBy.setTextSize(13);
        developedBy.setTypeface(Typeface.create(Typeface.SANS_SERIF, Typeface.ITALIC));
        developedBy.setTextColor(Color.rgb(133, 79, 108));
        developedBy.setGravity(Gravity.CENTER);
        developedBy.setPadding(0, 0, 0, dp(14));

        apiKeyInput = new EditText(this);
        apiKeyInput.setHint("Gemini API Key");
        apiKeyInput.setSingleLine(true);
        apiKeyInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        apiKeyInput.setText(prefs.getString(KEY_GEMINI_API_KEY, ""));
        styleInput(apiKeyInput);

        modelInput = new EditText(this);
        modelInput.setHint("Gemini model");
        modelInput.setSingleLine(true);
        modelInput.setText(prefs.getString(KEY_GEMINI_MODEL, DEFAULT_MODEL));
        styleInput(modelInput);

        customInstructionsInput = new EditText(this);
        customInstructionsInput.setHint("Custom instructions / معلوماتك وتعليماتك لجيميناي");
        customInstructionsInput.setMinLines(5);
        customInstructionsInput.setGravity(Gravity.TOP | Gravity.START);
        customInstructionsInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        customInstructionsInput.setText(prefs.getString(KEY_CUSTOM_INSTRUCTIONS, DEFAULT_CUSTOM_INSTRUCTIONS));
        styleInput(customInstructionsInput);

        Button surveyProfilesButton = new Button(this);
        surveyProfilesButton.setText("SURVEY PROFILES • 6");
        styleButton(surveyProfilesButton, Color.rgb(133, 79, 108));
        surveyProfilesButton.setOnClickListener(v -> showSurveyProfilesDialog());

        Button germanButton = new Button(this);
        germanButton.setText("GERMAN LEARNING • Deutsch");
        styleButton(germanButton, Color.rgb(82, 43, 91));
        germanButton.setOnClickListener(v -> showGermanLearningDialog());

        Button settingsButton = new Button(this);
        settingsButton.setText("SETTINGS • Language / Theme");
        styleButton(settingsButton, Color.rgb(43, 18, 76));
        settingsButton.setOnClickListener(v -> showSettingsDialog());

        Button saveButton = new Button(this);
        saveButton.setText("SAVE SETTINGS");
        styleButton(saveButton, Color.rgb(133, 79, 108));
        saveButton.setOnClickListener(v -> {
            String key = apiKeyInput.getText().toString().trim();
            String model = modelInput.getText().toString().trim();
            if (model.isEmpty()) model = DEFAULT_MODEL;
            prefs.edit()
                    .putString(KEY_GEMINI_API_KEY, key)
                    .putString(KEY_GEMINI_MODEL, model)
                    .putString(KEY_CUSTOM_INSTRUCTIONS, customInstructionsInput.getText().toString())
                    .apply();
            Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show();
            updateStatus();
        });

        statusText = new TextView(this);
        statusText.setTextSize(15);
        statusText.setTextColor(getPrimaryTextColor());
        statusText.setGravity(Gravity.CENTER);
        statusText.setPadding(dp(12), dp(14), dp(12), dp(14));
        statusText.setBackground(makeRoundDrawable(getCardColor(), Color.rgb(223, 182, 178), dp(20)));

        Button startButton = new Button(this);
        startButton.setText("START FLOATING AI");
        styleButton(startButton, Color.rgb(82, 43, 91));
        startButton.setOnClickListener(v -> startFlow());

        Button stopButton = new Button(this);
        stopButton.setText("STOP FLOATING BUTTON");
        styleButton(stopButton, Color.rgb(25, 0, 25));
        stopButton.setOnClickListener(v -> {
            stopService(new Intent(this, FloatingService.class));
            Toast.makeText(this, "Stopped", Toast.LENGTH_SHORT).show();
        });

        TextView help = new TextView(this);
        help.setText("نصائح:\n• اكتب بروفايلك أو طريقة الإجابة في Custom instructions.\n• الضغط القصير على AI يحلل الصفحة كاملة.\n• الضغط المطوّل على AI يغلق الزر العائم.\n• إذا علقت نافذة، زر STOP يغلق كل شيء.");
        help.setTextSize(13);
        help.setTextColor(getSecondaryTextColor());
        help.setPadding(dp(12), dp(16), dp(12), dp(0));

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, dp(6), 0, dp(10));
        root.addView(title, lp);
        root.addView(hint, lp);
        root.addView(developedBy, lp);
        root.addView(apiKeyInput, lp);
        root.addView(modelInput, lp);
        root.addView(customInstructionsInput, lp);
        root.addView(surveyProfilesButton, lp);
        root.addView(germanButton, lp);
        root.addView(settingsButton, lp);
        root.addView(saveButton, lp);
        root.addView(statusText, lp);
        root.addView(startButton, lp);
        root.addView(stopButton, lp);
        root.addView(help, lp);

        setContentView(scroller);

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 50);
        }

        updateStatus();
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateStatus();
    }

    private void startFlow() {
        String key = getSharedPreferences(PREFS, MODE_PRIVATE).getString(KEY_GEMINI_API_KEY, "");
        if (key == null || key.trim().isEmpty()) {
            Toast.makeText(this, "ضع Gemini API Key واضغط Save أولاً", Toast.LENGTH_LONG).show();
            return;
        }
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Enable Display over other apps", Toast.LENGTH_LONG).show();
            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
            startActivityForResult(intent, REQ_OVERLAY);
            return;
        }
        Intent captureIntent = projectionManager.createScreenCaptureIntent();
        startActivityForResult(captureIntent, REQ_SCREEN_CAPTURE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_SCREEN_CAPTURE) {
            if (resultCode == RESULT_OK && data != null) {
                Intent serviceIntent = new Intent(this, FloatingService.class);
                serviceIntent.putExtra("resultCode", resultCode);
                serviceIntent.putExtra("data", data);
                if (Build.VERSION.SDK_INT >= 26) {
                    startForegroundService(serviceIntent);
                } else {
                    startService(serviceIntent);
                }
                Toast.makeText(this, "Floating Gemini button started", Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(this, "Screen capture permission was not granted", Toast.LENGTH_LONG).show();
            }
        }
        updateStatus();
    }

    private void updateStatus() {
        boolean overlay = Settings.canDrawOverlays(this);
        String key = getSharedPreferences(PREFS, MODE_PRIVATE).getString(KEY_GEMINI_API_KEY, "");
        int activeProfile = getSharedPreferences(PREFS, MODE_PRIVATE).getInt(KEY_ACTIVE_SURVEY_PROFILE, 0) + 1;
        String language = getSharedPreferences(PREFS, MODE_PRIVATE).getString(KEY_LANGUAGE, "Arabic");
        String theme = getSharedPreferences(PREFS, MODE_PRIVATE).getString(KEY_THEME, "Light");
        String germanMode = getSharedPreferences(PREFS, MODE_PRIVATE).getString(KEY_GERMAN_MODE, "Off");
        statusText.setText("Overlay permission: " + (overlay ? "Enabled" : "Disabled") +
                "\nGemini key: " + ((key != null && !key.trim().isEmpty()) ? "Saved" : "Missing") +
                "\nActive survey profile: " + activeProfile + "/6" +
                "\nLanguage: " + language + "  •  Theme: " + theme +
                "\nGerman learning: " + germanMode +
                "\nScreen capture: will ask when you press Start" +
                "\nضغط قصير على AI = تحليل الصفحة كاملة" +
                "\nضغط مطوّل على AI = إغلاق الزر العائم");
    }


    private static final String[] PROFILE_FIELDS = new String[]{
            "Name", "Age", "Date of birth", "Race", "Relationship", "Gender",
            "Education", "Income", "State", "City", "Zip Code", "Occupation",
            "Children 1", "Children 2", "Address", "Survey memory / notes"
    };

    private void showSurveyProfilesDialog() {
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        Dialog dialog = new Dialog(this);
        ScrollView scrollView = new ScrollView(this);
        scrollView.setBackgroundColor(getScreenBgColor());

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(14), dp(16), dp(14), dp(16));
        scrollView.addView(box);

        TextView title = new TextView(this);
        title.setText("Survey Profiles");
        title.setTextColor(getPrimaryTextColor());
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setTextSize(24);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, 0, 0, dp(8));
        box.addView(title, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView sub = new TextView(this);
        sub.setText("كل بروفايل فيه خانات جاهزة. عبّي المعلومات، ثم اختر USE PROFILE ليجاوب Gemini على أساسها مع ذاكرة الاستبيان.");
        sub.setTextColor(getSecondaryTextColor());
        sub.setTextSize(14);
        sub.setGravity(Gravity.CENTER);
        sub.setPadding(0, 0, 0, dp(12));
        box.addView(sub, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        int active = prefs.getInt(KEY_ACTIVE_SURVEY_PROFILE, 0);
        EditText[][] inputs = new EditText[6][PROFILE_FIELDS.length];

        for (int i = 0; i < 6; i++) {
            final int index = i;
            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setPadding(dp(12), dp(12), dp(12), dp(12));
            card.setBackground(makeRoundDrawable(getCardColor(), i == active ? Color.rgb(133, 79, 108) : Color.rgb(223, 182, 178), dp(22)));
            LinearLayout.LayoutParams cardLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            cardLp.setMargins(0, dp(8), 0, dp(14));
            box.addView(card, cardLp);

            TextView label = new TextView(this);
            String savedName = prefs.getString(profileKey(i, "Name"), defaultProfileValue(i, "Name"));
            String displayName = savedName == null || savedName.trim().isEmpty() ? "empty" : savedName.trim();
            label.setText("Profile " + (i + 1) + " • " + displayName + (i == active ? "  • ACTIVE" : ""));
            label.setTextColor(i == active ? Color.rgb(133, 79, 108) : getPrimaryTextColor());
            label.setTypeface(Typeface.DEFAULT_BOLD);
            label.setTextSize(17);
            label.setPadding(0, 0, 0, dp(8));
            card.addView(label);

            for (int f = 0; f < PROFILE_FIELDS.length; f++) {
                String field = PROFILE_FIELDS[f];
                TextView fieldLabel = new TextView(this);
                fieldLabel.setText(field);
                fieldLabel.setTextColor(getSecondaryTextColor());
                fieldLabel.setTextSize(12.5f);
                fieldLabel.setTypeface(Typeface.DEFAULT_BOLD);
                fieldLabel.setPadding(dp(2), dp(6), dp(2), dp(2));
                card.addView(fieldLabel);

                EditText input = new EditText(this);
                input.setHint(field);
                input.setText(prefs.getString(profileKey(i, field), defaultProfileValue(i, field)));
                input.setSingleLine(!field.equals("Survey memory / notes") && !field.equals("Address"));
                if (field.equals("Survey memory / notes")) {
                    input.setMinLines(3);
                    input.setGravity(Gravity.TOP | Gravity.START);
                    input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
                } else {
                    input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
                }
                styleInput(input);
                inputs[i][f] = input;
                LinearLayout.LayoutParams inputLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                inputLp.setMargins(0, 0, 0, dp(4));
                card.addView(input, inputLp);
            }

            Button useButton = new Button(this);
            useButton.setText(i == active ? "USING PROFILE " + (i + 1) : "USE PROFILE " + (i + 1));
            styleButton(useButton, i == active ? Color.rgb(133, 79, 108) : Color.rgb(82, 43, 91));
            useButton.setOnClickListener(v -> {
                SharedPreferences.Editor editor = prefs.edit();
                saveProfileInputs(editor, inputs);
                String composed = composeProfileText(index, inputs[index]);
                editor.putInt(KEY_ACTIVE_SURVEY_PROFILE, index);
                editor.putString(KEY_CUSTOM_INSTRUCTIONS, composed);
                editor.apply();
                customInstructionsInput.setText(composed);
                Toast.makeText(this, "Profile " + (index + 1) + " selected", Toast.LENGTH_SHORT).show();
                updateStatus();
                dialog.dismiss();
            });
            LinearLayout.LayoutParams btnLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            btnLp.setMargins(0, dp(10), 0, 0);
            card.addView(useButton, btnLp);
        }

        Button saveAll = new Button(this);
        saveAll.setText("SAVE ALL PROFILES");
        styleButton(saveAll, Color.rgb(133, 79, 108));
        saveAll.setOnClickListener(v -> {
            SharedPreferences.Editor editor = prefs.edit();
            saveProfileInputs(editor, inputs);
            int currentActive = prefs.getInt(KEY_ACTIVE_SURVEY_PROFILE, 0);
            String composed = composeProfileText(currentActive, inputs[currentActive]);
            editor.putString(KEY_CUSTOM_INSTRUCTIONS, composed);
            editor.apply();
            customInstructionsInput.setText(composed);
            Toast.makeText(this, "All profiles saved", Toast.LENGTH_SHORT).show();
            updateStatus();
        });
        LinearLayout.LayoutParams saveLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        saveLp.setMargins(0, dp(12), 0, dp(8));
        box.addView(saveAll, saveLp);

        Button close = new Button(this);
        close.setText("CLOSE");
        styleButton(close, Color.rgb(25, 0, 25));
        close.setOnClickListener(v -> dialog.dismiss());
        box.addView(close, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        dialog.setContentView(scrollView);
        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
        }
        dialog.show();
        if (dialog.getWindow() != null) {
            dialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        }
    }

    private void saveProfileInputs(SharedPreferences.Editor editor, EditText[][] inputs) {
        for (int i = 0; i < inputs.length; i++) {
            for (int f = 0; f < PROFILE_FIELDS.length; f++) {
                editor.putString(profileKey(i, PROFILE_FIELDS[f]), inputs[i][f].getText().toString());
            }
        }
    }

    private String composeProfileText(int index, EditText[] inputs) {
        StringBuilder sb = new StringBuilder();
        sb.append("أجب على أساس Survey Profile ").append(index + 1).append(".\n");
        sb.append("استخدم هذه المعلومات كذاكرة ثابتة لهذا البروفايل عند إجابة الاستبيانات. ");
        sb.append("لا تذكر المعلومات الشخصية في الجواب إلا إذا كان السؤال يطلب ذلك.\n\n");
        for (int f = 0; f < PROFILE_FIELDS.length; f++) {
            String value = inputs[f].getText().toString().trim();
            if (!value.isEmpty()) {
                sb.append(PROFILE_FIELDS[f]).append(": ").append(value).append("\n");
            }
        }
        sb.append("\nطريقة الإجابة: أعطني الجواب المناسب أولاً، ثم سبب قصير، ثم مستوى الثقة. إذا كان السؤال اختياراً متعددًا، اختر فقط من الخيارات الظاهرة. إذا كان هناك تعارض بين الصفحة والبروفايل، اتبع معلومات البروفايل عندما يكون السؤال ديموغرافياً أو شخصياً.");
        return sb.toString();
    }

    private String profileKey(int profileIndex, String field) {
        String safe = field.toLowerCase(Locale.US).replace(" ", "_").replace("/", "_");
        return KEY_SURVEY_PROFILE_PREFIX + profileIndex + "_" + safe;
    }

    private String defaultProfileValue(int profileIndex, String field) {
        if (profileIndex != 0) return "";
        switch (field) {
            case "Name": return "Michael Jefferson";
            case "Age": return "40 years old";
            case "Date of birth": return "12/05/1985";
            case "Race": return "White / Caucasian";
            case "Relationship": return "Married";
            case "Gender": return "Male";
            case "Education": return "Bachelor's Degree (Engineering)";
            case "Income": return "$142,000 USD";
            case "State": return "New Jersey";
            case "City": return "Newark";
            case "Zip Code": return "07107";
            case "Occupation": return "Senior Project Manager (Construction & Infrastructure)";
            case "Children 1": return "9 years old (Boy)";
            case "Children 2": return "5 years old (Girl)";
            case "Address": return "311 Lake St, Newark, NJ 07104";
            case "Survey memory / notes": return "جاوب على أساس رجل متزوج لديه طفلان، يعمل بإدارة مشاريع البناء والبنية التحتية، دخله مرتفع، ويعيش في Newark, New Jersey. للاستبيانات، اختر إجابات واقعية ومتسقة مع هذا البروفايل.";
            default: return "";
        }
    }


    private void showSettingsDialog() {
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        Dialog dialog = new Dialog(this);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(18), dp(18), dp(18), dp(18));
        box.setBackground(makeRoundDrawable(getCardColor(), Color.rgb(223, 182, 178), dp(26)));

        TextView title = new TextView(this);
        title.setText("Settings");
        title.setTextSize(24);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setTextColor(getPrimaryTextColor());
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, 0, 0, dp(12));
        box.addView(title);

        TextView palette = new TextView(this);
        palette.setText("Palette: #190019 • #2B124C • #522B5B • #854F6C • #DFB6B2 • #FBE4D8");
        palette.setTextColor(getSecondaryTextColor());
        palette.setTextSize(13);
        palette.setGravity(Gravity.CENTER);
        palette.setPadding(0, 0, 0, dp(14));
        box.addView(palette);

        TextView langLabel = new TextView(this);
        langLabel.setText("Language / اللغة");
        langLabel.setTextColor(getPrimaryTextColor());
        langLabel.setTypeface(Typeface.DEFAULT_BOLD);
        langLabel.setTextSize(16);
        box.addView(langLabel);

        Button arabic = new Button(this);
        arabic.setText("Arabic");
        styleButton(arabic, Color.rgb(82, 43, 91));
        arabic.setOnClickListener(v -> { prefs.edit().putString(KEY_LANGUAGE, "Arabic").apply(); Toast.makeText(this, "Arabic selected", Toast.LENGTH_SHORT).show(); updateStatus(); });
        box.addView(arabic, matchLp());

        Button english = new Button(this);
        english.setText("English");
        styleButton(english, Color.rgb(133, 79, 108));
        english.setOnClickListener(v -> { prefs.edit().putString(KEY_LANGUAGE, "English").apply(); Toast.makeText(this, "English selected", Toast.LENGTH_SHORT).show(); updateStatus(); });
        box.addView(english, matchLp());

        TextView themeLabel = new TextView(this);
        themeLabel.setText("Theme / الوضع");
        themeLabel.setTextColor(getPrimaryTextColor());
        themeLabel.setTypeface(Typeface.DEFAULT_BOLD);
        themeLabel.setTextSize(16);
        themeLabel.setPadding(0, dp(12), 0, 0);
        box.addView(themeLabel);

        Button light = new Button(this);
        light.setText("Light mode / نهاري");
        styleButton(light, Color.rgb(133, 79, 108));
        light.setOnClickListener(v -> { prefs.edit().putString(KEY_THEME, "Light").apply(); Toast.makeText(this, "Light mode", Toast.LENGTH_SHORT).show(); recreate(); });
        box.addView(light, matchLp());

        Button dark = new Button(this);
        dark.setText("Dark mode / ليلي");
        styleButton(dark, Color.rgb(25, 0, 25));
        dark.setOnClickListener(v -> { prefs.edit().putString(KEY_THEME, "Dark").apply(); Toast.makeText(this, "Dark mode", Toast.LENGTH_SHORT).show(); recreate(); });
        box.addView(dark, matchLp());

        Button close = new Button(this);
        close.setText("Close");
        styleButton(close, Color.rgb(82, 43, 91));
        close.setOnClickListener(v -> dialog.dismiss());
        box.addView(close, matchLp());

        dialog.setContentView(box);
        dialog.show();
        if (dialog.getWindow() != null) dialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    private void showGermanLearningDialog() {
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        Dialog dialog = new Dialog(this);
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(getScreenBgColor());
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(16), dp(18), dp(16), dp(18));
        scroll.addView(box);

        TextView title = new TextView(this);
        title.setText("German Learning • Deutsch");
        title.setTextColor(getPrimaryTextColor());
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setTextSize(24);
        title.setGravity(Gravity.CENTER);
        box.addView(title);

        TextView sub = new TextView(this);
        sub.setText("اختر إعدادات تعلم الألمانية. لما تفعلها، Gemini يشرح الكلمات والقواعد حسب مستواك ويقدر يعمل تدريب سريع من أي شاشة.");
        sub.setTextColor(getSecondaryTextColor());
        sub.setTextSize(14);
        sub.setGravity(Gravity.CENTER);
        sub.setPadding(0, dp(6), 0, dp(12));
        box.addView(sub);

        EditText level = new EditText(this);
        level.setHint("Level: A1 / A2 / B1 / B2 / C1");
        level.setText(prefs.getString(KEY_GERMAN_LEVEL, "A1-A2"));
        styleInput(level);
        box.addView(level, matchLp());

        EditText goal = new EditText(this);
        goal.setHint("Goal: conversation, grammar, vocabulary, exam, work...");
        goal.setText(prefs.getString(KEY_GERMAN_GOAL, "Conversation + vocabulary + simple grammar"));
        styleInput(goal);
        box.addView(goal, matchLp());

        EditText mode = new EditText(this);
        mode.setHint("Mode: Explain / Translate / Quiz / Correct my sentence");
        mode.setText(prefs.getString(KEY_GERMAN_MODE, "Explain + Translate + Quiz"));
        styleInput(mode);
        box.addView(mode, matchLp());

        EditText notes = new EditText(this);
        notes.setHint("Notes: كلمات صعبة، أمثلة تريدها، طريقة الشرح...");
        notes.setMinLines(4);
        notes.setGravity(Gravity.TOP | Gravity.START);
        notes.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        notes.setText(prefs.getString(KEY_GERMAN_NOTES, "اشرح بالعربية المبسطة، أعطني ترجمة ألماني/عربي، مثالين، وتصحيح النطق إذا ظهر نص ألماني."));
        styleInput(notes);
        box.addView(notes, matchLp());

        Button use = new Button(this);
        use.setText("USE GERMAN LEARNING MODE");
        styleButton(use, Color.rgb(82, 43, 91));
        use.setOnClickListener(v -> {
            String composed = composeGermanInstructions(level.getText().toString(), goal.getText().toString(), mode.getText().toString(), notes.getText().toString());
            prefs.edit()
                    .putString(KEY_GERMAN_LEVEL, level.getText().toString())
                    .putString(KEY_GERMAN_GOAL, goal.getText().toString())
                    .putString(KEY_GERMAN_MODE, mode.getText().toString())
                    .putString(KEY_GERMAN_NOTES, notes.getText().toString())
                    .putString(KEY_CUSTOM_INSTRUCTIONS, composed)
                    .apply();
            customInstructionsInput.setText(composed);
            Toast.makeText(this, "German learning mode active", Toast.LENGTH_SHORT).show();
            updateStatus();
            dialog.dismiss();
        });
        box.addView(use, matchLp());

        Button save = new Button(this);
        save.setText("SAVE GERMAN SETTINGS ONLY");
        styleButton(save, Color.rgb(133, 79, 108));
        save.setOnClickListener(v -> {
            prefs.edit()
                    .putString(KEY_GERMAN_LEVEL, level.getText().toString())
                    .putString(KEY_GERMAN_GOAL, goal.getText().toString())
                    .putString(KEY_GERMAN_MODE, mode.getText().toString())
                    .putString(KEY_GERMAN_NOTES, notes.getText().toString())
                    .apply();
            Toast.makeText(this, "German settings saved", Toast.LENGTH_SHORT).show();
            updateStatus();
        });
        box.addView(save, matchLp());

        Button close = new Button(this);
        close.setText("CLOSE");
        styleButton(close, Color.rgb(25, 0, 25));
        close.setOnClickListener(v -> dialog.dismiss());
        box.addView(close, matchLp());

        dialog.setContentView(scroll);
        dialog.show();
        if (dialog.getWindow() != null) dialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
    }

    private String composeGermanInstructions(String level, String goal, String mode, String notes) {
        return "German Learning Mode فعال.\n" +
                "Level: " + level + "\n" +
                "Goal: " + goal + "\n" +
                "Mode: " + mode + "\n" +
                "Notes: " + notes + "\n\n" +
                "عند تحليل أي شاشة تحتوي ألمانية: استخرج الكلمات/الجمل الألمانية المهمة، ترجمها للعربية، اشرح القاعدة ببساطة حسب المستوى، أعطني أمثلة قصيرة، ثم تدريب سريع بسؤال واحد. إذا كانت الشاشة ليست ألمانية، أجب بشكل عادي ومختصر.";
    }

    private LinearLayout.LayoutParams matchLp() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, dp(6), 0, dp(8));
        return lp;
    }

    private boolean isDarkTheme() {
        return "Dark".equals(getSharedPreferences(PREFS, MODE_PRIVATE).getString(KEY_THEME, "Light"));
    }

    private int getScreenBgColor() { return isDarkTheme() ? Color.rgb(25, 0, 25) : Color.rgb(251, 228, 216); }
    private int getCardColor() { return isDarkTheme() ? Color.rgb(43, 18, 76) : Color.rgb(255, 246, 241); }
    private int getInputColor() { return isDarkTheme() ? Color.rgb(82, 43, 91) : Color.rgb(255, 250, 247); }
    private int getPrimaryTextColor() { return isDarkTheme() ? Color.rgb(251, 228, 216) : Color.rgb(43, 18, 76); }
    private int getSecondaryTextColor() { return isDarkTheme() ? Color.rgb(223, 182, 178) : Color.rgb(82, 43, 91); }

    private void styleInput(EditText input) {
        input.setTextColor(getPrimaryTextColor());
        input.setHintTextColor(getSecondaryTextColor());
        input.setTextSize(15);
        input.setPadding(dp(14), dp(10), dp(14), dp(10));
        input.setBackground(makeRoundDrawable(getInputColor(), Color.rgb(223, 182, 178), dp(18)));
    }

    private void styleButton(Button button, int color) {
        button.setTextColor(Color.WHITE);
        button.setTextSize(14);
        button.setTypeface(Typeface.DEFAULT_BOLD);
        button.setAllCaps(false);
        button.setPadding(dp(10), dp(12), dp(10), dp(12));
        button.setBackground(makeRoundDrawable(color, color, dp(18)));
    }

    private GradientDrawable makeRoundDrawable(int fill, int stroke, int radius) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setShape(GradientDrawable.RECTANGLE);
        drawable.setColor(fill);
        drawable.setCornerRadius(radius);
        drawable.setStroke(dp(1), stroke);
        return drawable;
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }
}
