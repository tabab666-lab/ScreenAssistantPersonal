Screen Assistant + Gemini - Step 5

ما الجديد:
1) خانة Custom instructions لإضافة معلوماتك وتعليماتك لجيميناي.
2) كل تحليل شاشة يستخدم التعليمات التي كتبتها.
3) نافذة جواب كبيرة مثل Ask AI فيها: X إغلاق، Copy نسخ، ↻ إعادة تحليل.
4) التطبيق يخفي زر AI والنافذة لحظة التقاط الشاشة حتى يحلل الصفحة الأصلية قدر الإمكان.
5) زر Stop داخل التطبيق يغلق الزر والنافذة.

طريقة الاستخدام:
- ضع Gemini API Key.
- اترك Gemini model مثل gemini-2.5-flash أو غيّره إذا أردت.
- اكتب معلوماتك/قواعد الإجابة في Custom instructions.
- اضغط Save Gemini Settings.
- اضغط Start Floating Gemini Button.
- اضغط AI فوق أي صفحة.
