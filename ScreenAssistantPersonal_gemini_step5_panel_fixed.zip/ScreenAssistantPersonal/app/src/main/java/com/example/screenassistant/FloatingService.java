package com.example.screenassistant;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Button;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.ByteBuffer;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class FloatingService extends Service {
    private static final String CHANNEL_ID = "screen_assistant_capture";

    private WindowManager windowManager;
    private TextView bubble;
    private LinearLayout answerPanel;
    private ScrollView answerScroll;
    private TextView answerText;
    private TextView headerTitle;
    private WindowManager.LayoutParams answerParams;

    private MediaProjection mediaProjection;
    private VirtualDisplay virtualDisplay;
    private ImageReader imageReader;
    private final Handler handler = new Handler(Looper.getMainLooper());

    private int screenWidth;
    private int screenHeight;
    private int screenDensity;

    private int initialX, initialY;
    private float initialTouchX, initialTouchY;
    private long downTime;
    private boolean busy = false;
    private boolean panelMinimized = false;

    @Override
    public void onCreate() {
        super.onCreate();
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        createNotificationChannel();
        startForeground(1, buildNotification("Screen Assistant + Gemini is ready"));

        if (intent != null && "ACTION_STOP_FLOATING".equals(intent.getAction())) {
            stopSelf();
            return START_NOT_STICKY;
        }

        if (bubble != null && mediaProjection != null) {
            return START_STICKY;
        }

        if (intent == null || !intent.hasExtra("resultCode") || !intent.hasExtra("data")) {
            Toast.makeText(this, "Missing screen capture permission. Open the app and press Start again.", Toast.LENGTH_LONG).show();
            stopSelf();
            return START_NOT_STICKY;
        }

        int resultCode = intent.getIntExtra("resultCode", 0);
        Intent data = intent.getParcelableExtra("data");
        MediaProjectionManager projectionManager = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        mediaProjection = projectionManager.getMediaProjection(resultCode, data);
        if (Build.VERSION.SDK_INT >= 21) {
            mediaProjection.registerCallback(new MediaProjection.Callback() {
                @Override
                public void onStop() {
                    cleanupProjection();
                }
            }, handler);
        }

        screenWidth = getResources().getDisplayMetrics().widthPixels;
        screenHeight = getResources().getDisplayMetrics().heightPixels;
        screenDensity = getResources().getDisplayMetrics().densityDpi;

        setupImageReader();
        showBubble();
        return START_STICKY;
    }

    private void setupImageReader() {
        cleanupProjectionDisplayOnly();
        imageReader = ImageReader.newInstance(screenWidth, screenHeight, PixelFormat.RGBA_8888, 2);
        virtualDisplay = mediaProjection.createVirtualDisplay(
                "ScreenAssistantCapture",
                screenWidth,
                screenHeight,
                screenDensity,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                imageReader.getSurface(),
                null,
                handler
        );
    }

    private void showBubble() {
        if (bubble != null) return;

        bubble = new TextView(this);
        bubble.setText("AI");
        bubble.setTextSize(18f);
        bubble.setTextColor(Color.WHITE);
        bubble.setGravity(Gravity.CENTER);
        bubble.setBackgroundColor(Color.rgb(20, 20, 20));
        bubble.setPadding(dp(22), dp(14), dp(22), dp(14));

        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT
        );
        params.gravity = Gravity.BOTTOM | Gravity.START;
        params.x = dp(16);
        params.y = dp(100);

        bubble.setOnTouchListener((view, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    downTime = System.currentTimeMillis();
                    initialX = params.x;
                    initialY = params.y;
                    initialTouchX = event.getRawX();
                    initialTouchY = event.getRawY();
                    return true;
                case MotionEvent.ACTION_MOVE:
                    params.x = initialX + (int) (event.getRawX() - initialTouchX);
                    params.y = initialY - (int) (event.getRawY() - initialTouchY);
                    windowManager.updateViewLayout(bubble, params);
                    return true;
                case MotionEvent.ACTION_UP:
                    float moved = Math.abs(event.getRawX() - initialTouchX) + Math.abs(event.getRawY() - initialTouchY);
                    long duration = System.currentTimeMillis() - downTime;
                    if (moved < 20) {
                        if (duration > 800) {
                            Toast.makeText(this, "Closing floating button", Toast.LENGTH_SHORT).show();
                            stopSelf();
                        } else {
                            captureNow();
                        }
                    }
                    return true;
            }
            return false;
        });

        windowManager.addView(bubble, params);
    }

    private void captureNow() {
        if (busy) {
            showAnswer("ما زال التحليل جارياً... انتظر قليلاً.", true);
            return;
        }
        busy = true;
        if (bubble != null) {
            bubble.setText("...");
            bubble.setVisibility(View.INVISIBLE);
        }
        if (answerPanel != null) answerPanel.setVisibility(View.INVISIBLE);

        // نخفي النوافذ العائمة لحظة الالتقاط حتى يرى Gemini الصفحة الأصلية وليس نافذتنا.
        handler.postDelayed(() -> {
            Image image = null;
            Bitmap cropped = null;
            try {
                image = imageReader.acquireLatestImage();
                if (bubble != null) bubble.setVisibility(View.VISIBLE);
                if (answerPanel != null) answerPanel.setVisibility(View.VISIBLE);

                if (image == null) {
                    showAnswer("ما قدرت ألتقط الصورة. جرّب اضغط AI مرة ثانية.", false);
                    finishBusy();
                    return;
                }

                Image.Plane[] planes = image.getPlanes();
                ByteBuffer buffer = planes[0].getBuffer();
                int pixelStride = planes[0].getPixelStride();
                int rowStride = planes[0].getRowStride();
                int rowPadding = rowStride - pixelStride * screenWidth;

                Bitmap bitmap = Bitmap.createBitmap(
                        screenWidth + rowPadding / pixelStride,
                        screenHeight,
                        Bitmap.Config.ARGB_8888
                );
                bitmap.copyPixelsFromBuffer(buffer);
                cropped = Bitmap.createBitmap(bitmap, 0, 0, screenWidth, screenHeight);
                bitmap.recycle();

                saveBitmap(cropped);
                showAnswer("جارٍ تحليل الصفحة كاملة حسب تعليماتك...", true);

                Bitmap finalBitmap = cropped;
                new Thread(() -> {
                    try {
                        String answer = askGemini(finalBitmap);
                        handler.post(() -> showAnswer(answer, false));
                    } catch (Exception e) {
                        handler.post(() -> showAnswer("خطأ Gemini: " + e.getMessage(), false));
                    } finally {
                        finalBitmap.recycle();
                        handler.post(this::finishBusy);
                    }
                }).start();

            } catch (Exception e) {
                if (bubble != null) bubble.setVisibility(View.VISIBLE);
                if (answerPanel != null) answerPanel.setVisibility(View.VISIBLE);
                if (cropped != null) cropped.recycle();
                showAnswer("خطأ أثناء الالتقاط: " + e.getMessage(), false);
                finishBusy();
            } finally {
                if (image != null) image.close();
            }
        }, 450);
    }

    private String askGemini(Bitmap screenshot) throws Exception {
        SharedPreferences prefs = getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE);
        String apiKey = prefs.getString(MainActivity.KEY_GEMINI_API_KEY, "");
        String model = prefs.getString(MainActivity.KEY_GEMINI_MODEL, MainActivity.DEFAULT_MODEL);
        String customInstructions = prefs.getString(MainActivity.KEY_CUSTOM_INSTRUCTIONS, MainActivity.DEFAULT_CUSTOM_INSTRUCTIONS);
        if (apiKey == null || apiKey.trim().isEmpty()) {
            return "Gemini API Key غير موجود. افتح التطبيق وضع المفتاح واضغط Save.";
        }
        if (model == null || model.trim().isEmpty()) model = MainActivity.DEFAULT_MODEL;

        String base64 = bitmapToBase64Jpeg(screenshot);
        String endpoint = "https://generativelanguage.googleapis.com/v1beta/models/" + model.trim() + ":generateContent";

        JSONObject inlineData = new JSONObject();
        inlineData.put("mime_type", "image/jpeg");
        inlineData.put("data", base64);

        JSONObject imagePart = new JSONObject();
        imagePart.put("inline_data", inlineData);

        JSONObject textPart = new JSONObject();
        String prompt = "تعليمات المستخدم الخاصة:\n" + (customInstructions == null ? "" : customInstructions.trim()) +
                "\n\nالمهمة الآن:\n" +
                "حلل كامل الشاشة الظاهرة كصفحة واحدة. إذا ظهر سؤال أو استبيان أو خيارات، استخرج السؤال والخيارات وأعطني الجواب المناسب أولاً. " +
                "إذا كانت الصفحة ليست سؤالاً، اشرح ماذا يظهر وما الخطوة العملية التالية. " +
                "اكتب بالعربية المختصرة والواضحة، واجعل النتيجة سهلة النسخ.";
        textPart.put("text", prompt);

        JSONArray parts = new JSONArray();
        parts.put(textPart);
        parts.put(imagePart);

        JSONObject content = new JSONObject();
        content.put("parts", parts);

        JSONArray contents = new JSONArray();
        contents.put(content);

        JSONObject generationConfig = new JSONObject();
        generationConfig.put("temperature", 0.2);
        generationConfig.put("maxOutputTokens", 1000);

        JSONObject body = new JSONObject();
        body.put("contents", contents);
        body.put("generationConfig", generationConfig);

        HttpURLConnection conn = (HttpURLConnection) new URL(endpoint).openConnection();
        conn.setRequestMethod("POST");
        conn.setConnectTimeout(30000);
        conn.setReadTimeout(60000);
        conn.setDoOutput(true);
        conn.setRequestProperty("Content-Type", "application/json");
        conn.setRequestProperty("x-goog-api-key", apiKey.trim());

        OutputStream os = conn.getOutputStream();
        os.write(body.toString().getBytes("UTF-8"));
        os.close();

        int code = conn.getResponseCode();
        InputStream input = code >= 200 && code < 300 ? conn.getInputStream() : conn.getErrorStream();
        String response = readAll(input);
        conn.disconnect();

        if (code < 200 || code >= 300) {
            return "Gemini رجّع خطأ HTTP " + code + ":\n" + response;
        }
        return extractGeminiText(response);
    }

    private String extractGeminiText(String json) {
        try {
            JSONObject root = new JSONObject(json);
            JSONArray candidates = root.optJSONArray("candidates");
            if (candidates == null || candidates.length() == 0) return "Gemini لم يرجع جواباً واضحاً.";
            JSONObject content = candidates.getJSONObject(0).optJSONObject("content");
            if (content == null) return "Gemini لم يرجع محتوى واضحاً.";
            JSONArray parts = content.optJSONArray("parts");
            if (parts == null || parts.length() == 0) return "Gemini لم يرجع نصاً.";

            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < parts.length(); i++) {
                String text = parts.getJSONObject(i).optString("text", "");
                if (!text.isEmpty()) sb.append(text).append("\n");
            }
            String result = sb.toString().trim();
            return result.isEmpty() ? "Gemini لم يرجع نصاً." : result;
        } catch (Exception e) {
            return "وصل رد من Gemini لكن لم أستطع قراءته:\n" + json;
        }
    }

    private String bitmapToBase64Jpeg(Bitmap bitmap) throws Exception {
        int maxWidth = 1080;
        Bitmap scaled = bitmap;
        if (bitmap.getWidth() > maxWidth) {
            int newHeight = (int) (((float) bitmap.getHeight() / bitmap.getWidth()) * maxWidth);
            scaled = Bitmap.createScaledBitmap(bitmap, maxWidth, newHeight, true);
        }
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        scaled.compress(Bitmap.CompressFormat.JPEG, 80, baos);
        if (scaled != bitmap) scaled.recycle();
        return Base64.encodeToString(baos.toByteArray(), Base64.NO_WRAP);
    }

    private String readAll(InputStream input) throws Exception {
        if (input == null) return "";
        BufferedReader br = new BufferedReader(new InputStreamReader(input, "UTF-8"));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = br.readLine()) != null) sb.append(line).append('\n');
        br.close();
        return sb.toString().trim();
    }

    private Uri saveBitmap(Bitmap bitmap) {
        try {
            String time = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
            String fileName = "screen_assistant_" + time + ".jpg";

            ContentResolver resolver = getContentResolver();
            ContentValues values = new ContentValues();
            values.put(MediaStore.Images.Media.DISPLAY_NAME, fileName);
            values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
            if (Build.VERSION.SDK_INT >= 29) {
                values.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/ScreenAssistant");
                values.put(MediaStore.Images.Media.IS_PENDING, 1);
            }

            Uri uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
            if (uri == null) return null;

            OutputStream out = resolver.openOutputStream(uri);
            bitmap.compress(Bitmap.CompressFormat.JPEG, 90, out);
            if (out != null) out.close();

            if (Build.VERSION.SDK_INT >= 29) {
                values.clear();
                values.put(MediaStore.Images.Media.IS_PENDING, 0);
                resolver.update(uri, values, null, null);
            }
            return uri;
        } catch (Exception e) {
            return null;
        }
    }

    private void ensureAnswerPanel(boolean loading) {
        if (answerPanel != null) return;

        answerPanel = new LinearLayout(this);
        answerPanel.setOrientation(LinearLayout.VERTICAL);
        answerPanel.setBackgroundColor(Color.argb(248, 10, 12, 28));
        answerPanel.setPadding(dp(12), dp(10), dp(12), dp(12));

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);

        headerTitle = new TextView(this);
        headerTitle.setTextColor(Color.WHITE);
        headerTitle.setTextSize(17f);
        headerTitle.setText(loading ? "ASK AI - analyzing" : "ASK AI - answer");

        LinearLayout.LayoutParams titleLp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        header.addView(headerTitle, titleLp);

        TextView again = makeHeaderButton("↻");
        again.setOnClickListener(v -> captureNow());
        header.addView(again);

        TextView copy = makeHeaderButton("Copy");
        copy.setTextSize(14f);
        copy.setOnClickListener(v -> copyAnswer());
        header.addView(copy);

        TextView minimize = makeHeaderButton(panelMinimized ? "□" : "—");
        minimize.setOnClickListener(v -> togglePanelMinimize());
        header.addView(minimize);

        TextView close = makeHeaderButton("✕");
        close.setOnClickListener(v -> removeAnswerPanel());
        header.addView(close);

        header.setOnTouchListener(new DragTouchListener());
        answerPanel.addView(header, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        answerScroll = new ScrollView(this);
        answerText = new TextView(this);
        answerText.setTextColor(Color.WHITE);
        answerText.setTextSize(15f);
        answerText.setLineSpacing(0f, 1.2f);
        answerText.setPadding(0, dp(10), 0, dp(8));
        answerScroll.addView(answerText);
        answerPanel.addView(answerScroll, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        TextView footer = new TextView(this);
        footer.setTextColor(Color.LTGRAY);
        footer.setTextSize(12f);
        footer.setText("X إغلاق • Copy نسخ • ↻ تحليل من جديد • اسحب الشريط العلوي لتحريك النافذة");
        answerPanel.addView(footer, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        answerParams = new WindowManager.LayoutParams(
                screenWidth - dp(24),
                (int) (screenHeight * 0.72f),
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT
        );
        answerParams.gravity = Gravity.TOP | Gravity.START;
        answerParams.x = dp(12);
        answerParams.y = dp(55);

        windowManager.addView(answerPanel, answerParams);
    }

    private TextView makeHeaderButton(String label) {
        TextView tv = new TextView(this);
        tv.setText(label);
        tv.setTextColor(Color.WHITE);
        tv.setTextSize(18f);
        tv.setGravity(Gravity.CENTER);
        tv.setPadding(dp(10), dp(4), dp(10), dp(4));
        return tv;
    }

    private class DragTouchListener implements View.OnTouchListener {
        private int startX, startY;
        private float touchX, touchY;

        @Override
        public boolean onTouch(View v, MotionEvent event) {
            if (answerParams == null) return false;
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    startX = answerParams.x;
                    startY = answerParams.y;
                    touchX = event.getRawX();
                    touchY = event.getRawY();
                    return true;
                case MotionEvent.ACTION_MOVE:
                    answerParams.x = startX + (int) (event.getRawX() - touchX);
                    answerParams.y = startY + (int) (event.getRawY() - touchY);
                    if (answerPanel != null) windowManager.updateViewLayout(answerPanel, answerParams);
                    return true;
            }
            return false;
        }
    }

    private void togglePanelMinimize() {
        if (answerPanel == null || answerScroll == null || answerParams == null) return;
        panelMinimized = !panelMinimized;
        answerScroll.setVisibility(panelMinimized ? View.GONE : View.VISIBLE);
        int footerIndex = 2;
        if (answerPanel.getChildCount() > footerIndex) {
            View footer = answerPanel.getChildAt(footerIndex);
            footer.setVisibility(panelMinimized ? View.GONE : View.VISIBLE);
        }
        answerParams.height = panelMinimized ? WindowManager.LayoutParams.WRAP_CONTENT : (int) (screenHeight * 0.72f);
        windowManager.updateViewLayout(answerPanel, answerParams);
    }

    private void removeAnswerPanel() {
        try {
            if (answerPanel != null) {
                windowManager.removeView(answerPanel);
            }
        } catch (Exception ignored) {
        }
        answerPanel = null;
        answerScroll = null;
        answerText = null;
        headerTitle = null;
        answerParams = null;
        panelMinimized = false;
    }

    private void showAnswer(String text, boolean loading) {
        ensureAnswerPanel(loading);
        if (headerTitle != null) headerTitle.setText(loading ? "ASK AI - analyzing" : "ASK AI - answer");
        if (answerText != null) answerText.setText(text);
        if (answerScroll != null) answerScroll.scrollTo(0, 0);
        if (answerPanel != null && panelMinimized) {
            togglePanelMinimize();
        }
    }

    private void copyAnswer() {
        try {
            if (answerText == null) return;
            ClipboardManager clipboard = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
            clipboard.setPrimaryClip(ClipData.newPlainText("Gemini answer", answerText.getText().toString()));
            Toast.makeText(this, "Copied", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Copy failed", Toast.LENGTH_SHORT).show();
        }
    }

    private void finishBusy() {
        busy = false;
        if (bubble != null) bubble.setText("AI");
    }

    private Notification buildNotification(String text) {
        Intent openIntent = new Intent(this, MainActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(
                this,
                0,
                openIntent,
                Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0
        );

        Notification.Builder builder = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL_ID)
                : new Notification.Builder(this);

        return builder
                .setContentTitle("Screen Assistant + Gemini")
                .setContentText(text)
                .setSmallIcon(android.R.drawable.ic_menu_camera)
                .setContentIntent(pendingIntent)
                .setOngoing(true)
                .build();
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    "Screen Assistant Capture",
                    NotificationManager.IMPORTANCE_LOW
            );
            NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            manager.createNotificationChannel(channel);
        }
    }

    private void cleanupProjectionDisplayOnly() {
        if (virtualDisplay != null) {
            virtualDisplay.release();
            virtualDisplay = null;
        }
        if (imageReader != null) {
            imageReader.close();
            imageReader = null;
        }
    }

    private void cleanupProjection() {
        cleanupProjectionDisplayOnly();
        mediaProjection = null;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        try {
            if (bubble != null) windowManager.removeView(bubble);
        } catch (Exception ignored) {
        }
        removeAnswerPanel();
        cleanupProjectionDisplayOnly();
        if (mediaProjection != null) {
            mediaProjection.stop();
            mediaProjection = null;
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density);
    }
}
