Z.D.SURV - Final Private Cache Fix

هذه نسخة نهائية معدلة:
- لا تحفظ صور السكرينشوت في Gallery / Photos / Studio.
- تستخدم Cache خاص داخل التطبيق فقط.
- تحليل Gemini يعمل من الصورة الموجودة بالذاكرة، وليس من الاستديو.
- حذف تلقائي للصور المؤقتة.
- بدون FileProvider/AndroidX حتى لا ينكسر البناء على GitHub.
