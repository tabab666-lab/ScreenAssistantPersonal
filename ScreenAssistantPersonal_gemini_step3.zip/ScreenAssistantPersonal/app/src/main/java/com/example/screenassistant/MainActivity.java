package com.example.screenassistant;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    public static final String PREFS = "screen_assistant_prefs";
    public static final String KEY_GEMINI_API_KEY = "gemini_api_key";
    public static final String KEY_GEMINI_MODEL = "gemini_model";
    public static final String DEFAULT_MODEL = "gemini-2.5-flash";

    private static final int REQ_OVERLAY = 100;
    private static final int REQ_SCREEN_CAPTURE = 200;
    private MediaProjectionManager projectionManager;
    private TextView statusText;
    private EditText apiKeyInput;
    private EditText modelInput;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        projectionManager = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);

        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        int pad = dp(22);
        root.setPadding(pad, pad, pad, pad);

        TextView title = new TextView(this);
        title.setText("Screen Assistant + Gemini");
        title.setTextSize(24);
        title.setGravity(Gravity.CENTER);

        TextView hint = new TextView(this);
        hint.setText("ضع Gemini API Key مرة واحدة، ثم اضغط Save، وبعدها Start.\nملاحظة: هذا مناسب للاستخدام الشخصي فقط وليس للنشر.");
        hint.setTextSize(14);
        hint.setGravity(Gravity.CENTER);
        hint.setPadding(0, dp(10), 0, dp(10));

        apiKeyInput = new EditText(this);
        apiKeyInput.setHint("Gemini API Key");
        apiKeyInput.setSingleLine(true);
        apiKeyInput.setText(prefs.getString(KEY_GEMINI_API_KEY, ""));

        modelInput = new EditText(this);
        modelInput.setHint("Gemini model");
        modelInput.setSingleLine(true);
        modelInput.setText(prefs.getString(KEY_GEMINI_MODEL, DEFAULT_MODEL));

        Button saveButton = new Button(this);
        saveButton.setText("Save Gemini Settings");
        saveButton.setOnClickListener(v -> {
            String key = apiKeyInput.getText().toString().trim();
            String model = modelInput.getText().toString().trim();
            if (model.isEmpty()) model = DEFAULT_MODEL;
            prefs.edit()
                    .putString(KEY_GEMINI_API_KEY, key)
                    .putString(KEY_GEMINI_MODEL, model)
                    .apply();
            Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show();
            updateStatus();
        });

        statusText = new TextView(this);
        statusText.setTextSize(16);
        statusText.setGravity(Gravity.CENTER);
        statusText.setPadding(0, dp(16), 0, dp(16));

        Button startButton = new Button(this);
        startButton.setText("Start Floating Gemini Button");
        startButton.setOnClickListener(v -> startFlow());

        Button stopButton = new Button(this);
        stopButton.setText("Stop Floating Button");
        stopButton.setOnClickListener(v -> {
            stopService(new Intent(this, FloatingService.class));
            Toast.makeText(this, "Stopped", Toast.LENGTH_SHORT).show();
        });

        root.addView(title, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(hint, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(apiKeyInput, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(modelInput, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(saveButton, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(statusText, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(startButton, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(stopButton, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        setContentView(root);

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 50);
        }

        updateStatus();
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateStatus();
    }

    private void startFlow() {
        String key = getSharedPreferences(PREFS, MODE_PRIVATE).getString(KEY_GEMINI_API_KEY, "");
        if (key == null || key.trim().isEmpty()) {
            Toast.makeText(this, "ضع Gemini API Key واضغط Save أولاً", Toast.LENGTH_LONG).show();
            return;
        }
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Enable Display over other apps", Toast.LENGTH_LONG).show();
            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
            startActivityForResult(intent, REQ_OVERLAY);
            return;
        }
        Intent captureIntent = projectionManager.createScreenCaptureIntent();
        startActivityForResult(captureIntent, REQ_SCREEN_CAPTURE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_SCREEN_CAPTURE) {
            if (resultCode == RESULT_OK && data != null) {
                Intent serviceIntent = new Intent(this, FloatingService.class);
                serviceIntent.putExtra("resultCode", resultCode);
                serviceIntent.putExtra("data", data);
                if (Build.VERSION.SDK_INT >= 26) {
                    startForegroundService(serviceIntent);
                } else {
                    startService(serviceIntent);
                }
                Toast.makeText(this, "Floating Gemini button started", Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(this, "Screen capture permission was not granted", Toast.LENGTH_LONG).show();
            }
        }
        updateStatus();
    }

    private void updateStatus() {
        boolean overlay = Settings.canDrawOverlays(this);
        String key = getSharedPreferences(PREFS, MODE_PRIVATE).getString(KEY_GEMINI_API_KEY, "");
        statusText.setText("Overlay permission: " + (overlay ? "Enabled" : "Disabled") +
                "\nGemini key: " + ((key != null && !key.trim().isEmpty()) ? "Saved" : "Missing") +
                "\nScreen capture: will ask when you press Start" +
                "\nاضغط AI فوق أي شاشة ليحللها Gemini.");
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }
}
