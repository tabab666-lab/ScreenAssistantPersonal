package com.example.screenassistant;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.WindowManager;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.ByteBuffer;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class FloatingService extends Service {
    private static final String CHANNEL_ID = "screen_assistant_capture";
    private WindowManager windowManager;
    private TextView bubble;
    private TextView answerBox;
    private MediaProjection mediaProjection;
    private VirtualDisplay virtualDisplay;
    private ImageReader imageReader;
    private Handler handler = new Handler(Looper.getMainLooper());

    private int screenWidth;
    private int screenHeight;
    private int screenDensity;

    private int initialX, initialY;
    private float initialTouchX, initialTouchY;
    private long downTime;
    private boolean busy = false;

    @Override
    public void onCreate() {
        super.onCreate();
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        createNotificationChannel();
        startForeground(1, buildNotification("Screen Assistant + Gemini is ready"));

        if (intent == null || !intent.hasExtra("resultCode") || !intent.hasExtra("data")) {
            Toast.makeText(this, "Missing screen capture permission. Open the app and press Start again.", Toast.LENGTH_LONG).show();
            stopSelf();
            return START_NOT_STICKY;
        }

        int resultCode = intent.getIntExtra("resultCode", 0);
        Intent data = intent.getParcelableExtra("data");
        MediaProjectionManager projectionManager = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        mediaProjection = projectionManager.getMediaProjection(resultCode, data);
        mediaProjection.registerCallback(new MediaProjection.Callback() {
            @Override
            public void onStop() {
                cleanupProjection();
            }
        }, handler);

        screenWidth = getResources().getDisplayMetrics().widthPixels;
        screenHeight = getResources().getDisplayMetrics().heightPixels;
        screenDensity = getResources().getDisplayMetrics().densityDpi;

        setupImageReader();
        showBubble();
        return START_STICKY;
    }

    private void setupImageReader() {
        cleanupProjectionDisplayOnly();
        imageReader = ImageReader.newInstance(screenWidth, screenHeight, PixelFormat.RGBA_8888, 2);
        virtualDisplay = mediaProjection.createVirtualDisplay(
                "ScreenAssistantCapture",
                screenWidth,
                screenHeight,
                screenDensity,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                imageReader.getSurface(),
                null,
                handler
        );
    }

    private void showBubble() {
        if (bubble != null) return;

        bubble = new TextView(this);
        bubble.setText("AI");
        bubble.setTextSize(18f);
        bubble.setTextColor(android.graphics.Color.WHITE);
        bubble.setGravity(Gravity.CENTER);
        bubble.setBackgroundColor(android.graphics.Color.rgb(20, 20, 20));
        bubble.setPadding(dp(22), dp(14), dp(22), dp(14));

        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT
        );
        params.gravity = Gravity.TOP | Gravity.START;
        params.x = dp(24);
        params.y = dp(180);

        bubble.setOnTouchListener((view, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    downTime = System.currentTimeMillis();
                    initialX = params.x;
                    initialY = params.y;
                    initialTouchX = event.getRawX();
                    initialTouchY = event.getRawY();
                    return true;
                case MotionEvent.ACTION_MOVE:
                    params.x = initialX + (int) (event.getRawX() - initialTouchX);
                    params.y = initialY + (int) (event.getRawY() - initialTouchY);
                    windowManager.updateViewLayout(bubble, params);
                    return true;
                case MotionEvent.ACTION_UP:
                    float moved = Math.abs(event.getRawX() - initialTouchX) + Math.abs(event.getRawY() - initialTouchY);
                    if (moved < 20 && System.currentTimeMillis() - downTime < 500) {
                        captureAndAskGemini();
                    }
                    return true;
            }
            return false;
        });

        windowManager.addView(bubble, params);
    }

    private void captureAndAskGemini() {
        if (busy) return;
        busy = true;
        if (bubble != null) bubble.setText("...");
        showAnswer("جارٍ التقاط الشاشة وتحليلها عبر Gemini...");

        handler.postDelayed(() -> {
            Image image = null;
            Bitmap cropped = null;
            try {
                image = imageReader.acquireLatestImage();
                if (image == null) {
                    showAnswer("ما قدرت ألتقط الصورة. جرّب اضغط AI مرة ثانية.");
                    finishBusy();
                    return;
                }

                Image.Plane[] planes = image.getPlanes();
                ByteBuffer buffer = planes[0].getBuffer();
                int pixelStride = planes[0].getPixelStride();
                int rowStride = planes[0].getRowStride();
                int rowPadding = rowStride - pixelStride * screenWidth;

                Bitmap bitmap = Bitmap.createBitmap(
                        screenWidth + rowPadding / pixelStride,
                        screenHeight,
                        Bitmap.Config.ARGB_8888
                );
                bitmap.copyPixelsFromBuffer(buffer);
                cropped = Bitmap.createBitmap(bitmap, 0, 0, screenWidth, screenHeight);
                bitmap.recycle();

                // اختياري: نحفظ نسخة بالصورة لتتأكد أن الالتقاط يعمل.
                saveBitmap(cropped);

                Bitmap finalBitmap = cropped;
                new Thread(() -> {
                    try {
                        String answer = askGemini(finalBitmap);
                        handler.post(() -> showAnswer(answer));
                    } catch (Exception e) {
                        handler.post(() -> showAnswer("خطأ Gemini: " + e.getMessage()));
                    } finally {
                        finalBitmap.recycle();
                        handler.post(this::finishBusy);
                    }
                }).start();

            } catch (Exception e) {
                if (cropped != null) cropped.recycle();
                showAnswer("خطأ أثناء الالتقاط: " + e.getMessage());
                finishBusy();
            } finally {
                if (image != null) image.close();
            }
        }, 350);
    }

    private String askGemini(Bitmap screenshot) throws Exception {
        SharedPreferences prefs = getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE);
        String apiKey = prefs.getString(MainActivity.KEY_GEMINI_API_KEY, "");
        String model = prefs.getString(MainActivity.KEY_GEMINI_MODEL, MainActivity.DEFAULT_MODEL);
        if (apiKey == null || apiKey.trim().isEmpty()) {
            return "Gemini API Key غير موجود. افتح التطبيق وضع المفتاح واضغط Save.";
        }
        if (model == null || model.trim().isEmpty()) model = MainActivity.DEFAULT_MODEL;

        String base64 = bitmapToBase64Jpeg(screenshot);
        String endpoint = "https://generativelanguage.googleapis.com/v1beta/models/" + model.trim() + ":generateContent";

        JSONObject inlineData = new JSONObject();
        inlineData.put("mime_type", "image/jpeg");
        inlineData.put("data", base64);

        JSONObject imagePart = new JSONObject();
        imagePart.put("inline_data", inlineData);

        JSONObject textPart = new JSONObject();
        textPart.put("text", "حلل هذه الصورة. إذا فيها سؤال أو واجهة تطبيق، أعطني الجواب أو الخطوة التالية بالعربية وبشكل مختصر وواضح. لا تذكر أنك لا تستطيع رؤية الصورة إلا إذا كانت غير واضحة فعلاً.");

        JSONArray parts = new JSONArray();
        parts.put(textPart);
        parts.put(imagePart);

        JSONObject content = new JSONObject();
        content.put("parts", parts);

        JSONArray contents = new JSONArray();
        contents.put(content);

        JSONObject generationConfig = new JSONObject();
        generationConfig.put("temperature", 0.2);
        generationConfig.put("maxOutputTokens", 600);

        JSONObject body = new JSONObject();
        body.put("contents", contents);
        body.put("generationConfig", generationConfig);

        HttpURLConnection conn = (HttpURLConnection) new URL(endpoint).openConnection();
        conn.setRequestMethod("POST");
        conn.setConnectTimeout(30000);
        conn.setReadTimeout(60000);
        conn.setDoOutput(true);
        conn.setRequestProperty("Content-Type", "application/json");
        conn.setRequestProperty("x-goog-api-key", apiKey.trim());

        OutputStream os = conn.getOutputStream();
        os.write(body.toString().getBytes("UTF-8"));
        os.close();

        int code = conn.getResponseCode();
        InputStream input = code >= 200 && code < 300 ? conn.getInputStream() : conn.getErrorStream();
        String response = readAll(input);
        conn.disconnect();

        if (code < 200 || code >= 300) {
            return "Gemini رجّع خطأ HTTP " + code + ":\n" + response;
        }
        return extractGeminiText(response);
    }

    private String extractGeminiText(String json) {
        try {
            JSONObject root = new JSONObject(json);
            JSONArray candidates = root.optJSONArray("candidates");
            if (candidates == null || candidates.length() == 0) return "Gemini لم يرجع جواباً واضحاً.";
            JSONObject content = candidates.getJSONObject(0).optJSONObject("content");
            if (content == null) return "Gemini لم يرجع محتوى واضحاً.";
            JSONArray parts = content.optJSONArray("parts");
            if (parts == null || parts.length() == 0) return "Gemini لم يرجع نصاً.";

            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < parts.length(); i++) {
                String text = parts.getJSONObject(i).optString("text", "");
                if (!text.isEmpty()) sb.append(text).append("\n");
            }
            String result = sb.toString().trim();
            return result.isEmpty() ? "Gemini لم يرجع نصاً." : result;
        } catch (Exception e) {
            return "وصل رد من Gemini لكن لم أستطع قراءته:\n" + json;
        }
    }

    private String bitmapToBase64Jpeg(Bitmap bitmap) throws Exception {
        int maxWidth = 1080;
        Bitmap scaled = bitmap;
        if (bitmap.getWidth() > maxWidth) {
            int newHeight = (int) (((float) bitmap.getHeight() / bitmap.getWidth()) * maxWidth);
            scaled = Bitmap.createScaledBitmap(bitmap, maxWidth, newHeight, true);
        }
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        scaled.compress(Bitmap.CompressFormat.JPEG, 80, baos);
        if (scaled != bitmap) scaled.recycle();
        return Base64.encodeToString(baos.toByteArray(), Base64.NO_WRAP);
    }

    private String readAll(InputStream input) throws Exception {
        if (input == null) return "";
        BufferedReader br = new BufferedReader(new InputStreamReader(input, "UTF-8"));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = br.readLine()) != null) sb.append(line).append('\n');
        br.close();
        return sb.toString().trim();
    }

    private Uri saveBitmap(Bitmap bitmap) {
        try {
            String time = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
            String fileName = "screen_assistant_" + time + ".jpg";

            ContentResolver resolver = getContentResolver();
            ContentValues values = new ContentValues();
            values.put(MediaStore.Images.Media.DISPLAY_NAME, fileName);
            values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
            if (Build.VERSION.SDK_INT >= 29) {
                values.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/ScreenAssistant");
                values.put(MediaStore.Images.Media.IS_PENDING, 1);
            }

            Uri uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
            if (uri == null) return null;

            OutputStream out = resolver.openOutputStream(uri);
            bitmap.compress(Bitmap.CompressFormat.JPEG, 90, out);
            if (out != null) out.close();

            if (Build.VERSION.SDK_INT >= 29) {
                values.clear();
                values.put(MediaStore.Images.Media.IS_PENDING, 0);
                resolver.update(uri, values, null, null);
            }
            return uri;
        } catch (Exception e) {
            return null;
        }
    }

    private void finishBusy() {
        busy = false;
        if (bubble != null) bubble.setText("AI");
    }

    private void showAnswer(String text) {
        if (answerBox == null) {
            answerBox = new TextView(this);
            answerBox.setTextSize(15f);
            answerBox.setTextColor(android.graphics.Color.WHITE);
            answerBox.setBackgroundColor(android.graphics.Color.rgb(45, 45, 45));
            answerBox.setPadding(dp(16), dp(12), dp(16), dp(12));

            WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                    dp(330),
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                    PixelFormat.TRANSLUCENT
            );
            params.gravity = Gravity.TOP | Gravity.START;
            params.x = dp(16);
            params.y = dp(260);
            windowManager.addView(answerBox, params);
        }
        answerBox.setText(text);
    }

    private Notification buildNotification(String text) {
        Intent openIntent = new Intent(this, MainActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(
                this,
                0,
                openIntent,
                Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0
        );

        Notification.Builder builder = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL_ID)
                : new Notification.Builder(this);

        return builder
                .setContentTitle("Screen Assistant + Gemini")
                .setContentText(text)
                .setSmallIcon(android.R.drawable.ic_menu_camera)
                .setContentIntent(pendingIntent)
                .setOngoing(true)
                .build();
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    "Screen Assistant Capture",
                    NotificationManager.IMPORTANCE_LOW
            );
            NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            manager.createNotificationChannel(channel);
        }
    }

    private void cleanupProjectionDisplayOnly() {
        if (virtualDisplay != null) {
            virtualDisplay.release();
            virtualDisplay = null;
        }
        if (imageReader != null) {
            imageReader.close();
            imageReader = null;
        }
    }

    private void cleanupProjection() {
        cleanupProjectionDisplayOnly();
        mediaProjection = null;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        try {
            if (bubble != null) windowManager.removeView(bubble);
            if (answerBox != null) windowManager.removeView(answerBox);
        } catch (Exception ignored) {}
        cleanupProjectionDisplayOnly();
        if (mediaProjection != null) {
            mediaProjection.stop();
            mediaProjection = null;
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density);
    }
}
